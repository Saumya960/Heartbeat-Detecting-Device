#ifndef STUDENT_GRADE_CALCULATOR_GRADE_H
#define STUDENT_GRADE_CALCULATOR_GRADE_H
#include <stdio.h>
#include <stddef.h>

#define MAX_SUBJECTS 100
#define MAX_NAME_LEN 50
#define MAX_SUBJECT_NAME_LEN 50
#define MAX_INPUT_LEN 100
#define SCORE_MIN 0
#define SCORE_MAX 100
//structure for a single subject
typedef struct {
    char name[MAX_SUBJECT_NAME_LEN];
    int score;
    int grade;
}subject;
//structure for a student with subjects
typedef struct {
    char name[MAX_NAME_LEN];
    int subject_count;
    subject subjects[MAX_SUBJECTS];
}student;


//function declarations
int calculate_grade(int score);   //convert a score to a grade
float calculate_average_grade(student s);   //calculate average grade of all subjects
int remove_linefeed(char *string);   // remove new line character from string
int read_line(FILE *in, const char *prompt, char *buffer, size_t buffer_size, int *too_long);
int read_int_in_range(FILE *in, const char *prompt, int min, int max, int *out_value);
int read_score_for_subject(FILE *in, const char *subject_name, int min, int max, int *out_score);
int digit_only_name(const char *str);

#endif //STUDENT_GRADE_CALCULATOR_GRADE_H