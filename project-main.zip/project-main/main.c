#include "grade.h"
#include "report.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    student s;

    printf("Welcome to the Student Grade Calculator!\n");
    int valid_name = 0;     //to check if user entered a valid name
    while (!valid_name) {
        int too_long = 0;
        printf("Please enter your name: ");
        fflush(stdout);
        //read name safely
        if (!read_line(stdin, NULL, s.name, MAX_NAME_LEN, &too_long)) {
            printf("Input error!\n");
            return 1;
        }
        if (too_long) {           //check different name errors
            printf("Too long name (max %d characters). Try again.\n",MAX_NAME_LEN - 1);
        } else if (s.name[0] == '\0') {    //when just pressed enter
            printf("Please enter a valid name!\n");
        } else if (digit_only_name(s.name)) {     //when entered name is only numbers
            printf("Name can not be only numbers. Please enter letters.\n");
        } else {
            valid_name = 1;     //name is ok
        }
    }

    int valid_subject_count = 0;
    while (!valid_subject_count) {
        int count = 0;
        //to ask how many subjects
        if (!read_int_in_range(stdin, "How many subjects do you want to calculate grade for? ", 1, MAX_SUBJECTS, &count)) {
            printf("Input error!\n");
            return 1;
        } else {
            s.subject_count = count;
            valid_subject_count = 1;    // accepted number
        }

    }
    //get subject names and errors
    for (int i = 0; i < s.subject_count; i++) {
        int valid_subject_name = 0;
        while (!valid_subject_name) {
            int too_long = 0;

            printf("Enter subject %d name: ", i + 1);
            fflush(stdout);
            if (!read_line(stdin, NULL, s.subjects[i].name, MAX_SUBJECT_NAME_LEN, &too_long)) {
                printf("Input error!\n");
                return 1;
            }
            if (too_long) {
                printf("Subjetc name is too long!\n", MAX_SUBJECT_NAME_LEN - 1);
            } else if (s.subjects[i].name[0] == '\0') {
                printf("Subject name is empty.Try again.\n");
            } else {
                valid_subject_name = 1;     //accepted subject name
            }
        }


        int score = 0;
        //read score for subject
        if (!read_score_for_subject(stdin, s.subjects[i].name, SCORE_MIN, SCORE_MAX, &score)) {
            printf("Input error!");
            return 1;
        }
        s.subjects[i].score = score;
        s.subjects[i].grade = calculate_grade(score);    //calculate grade

    }
    print_report(s);     //show report on screen
    write_report_to_file(s, "report.txt");    //also save to file
    return 0;
}
