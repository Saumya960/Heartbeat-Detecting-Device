#include "grade.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

//takes a score and returns a grade
int calculate_grade(int score) {
    if (score >= 90){
        return 5;
    } if (score >= 80){
        return 4;
    } if (score >= 70){
        return 3;
    } if (score >= 60){
        return 2;
    } if (score >= 50){
        return 1;
    }
    return 0;
}

int remove_linefeed(char *string) {    //remove newline at end of input
    if (!string) {
        return 0;
    }
    size_t len = strlen(string);
    if (len == 0) {
        return 0;
    }
    if (string[len - 1] == '\n') {
        string[--len] = '\0';
        if (len > 1 && string[len - 1] == '\r')
            string[--len] = '\0';
        return 0;
    } else {     //clear leftover input
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF) {
        }
        return 1;
    }
}

//check if name has only numbers
int digit_only_name(const char *str) {
    if (!str) {
        return 0;
    }
    int has_digit = 0;
    while (*str && isspace((unsigned char)*str)) {   //skip spaces
        str++;
    }
    while (*str) {
        if (isspace((unsigned char)*str)) {
           //to allow spaces inside name
        } else if (isdigit((unsigned char)*str)) {
            has_digit = 1;
        } else {
            return 0;
        }
        str++;
    }
    return has_digit;
}
//safely read a line of text
int read_line(FILE *in, const char *prompt, char *buffer, size_t buffer_size, int *too_long) {
    if (prompt) {
        fputs(prompt, stdout);
        fflush(stdout);
    }
    if (!buffer || buffer_size == 0) {
        return 0;
    }if (!fgets(buffer, (int)buffer_size, in)) {
        return 0;
    }

    {
        int tl = remove_linefeed(buffer);
        if (too_long) *too_long = tl;
    }
    return 1;
}
//read integer within range
int read_int_in_range(FILE *in, const char *prompt, int min, int max, int *out_value) {
    char line[MAX_INPUT_LEN];
    int value = 0;
    int valid = 0;

    while (!valid) {
        int tl = 0;
        if (!read_line(in, prompt, line, sizeof(line), &tl)) {
            return 0;
        }
        if (line[0] == '\0') {
            printf("Input can not be empty!\n");
        } else if (sscanf(line, "%d", &value) != 1) {
            printf("Invalid input. Please enter a number.\n");
        } else if (value < min || value > max) {
            printf("Value must be between %d and %d.\n", min, max);
        } else {
            valid = 1;
        }
    }
    if (out_value) *out_value = value;
    return 1;
}
//read a score for a subject
int read_score_for_subject(FILE *in, const char *subject_name, int min, int max, int *out_score) {
    char line[MAX_INPUT_LEN];
    int value = 0;
    int valid = 0;

    while (!valid) {
        int too_long = 0;
        printf("Enter your score for %s (%d-%d): ", subject_name, min, max);
        fflush(stdout);

        if (!read_line(in, NULL, line, sizeof(line), &too_long)) {
            return 0;
        }
        if (too_long) {
            printf("Enter valid score!\n");
        } else if (line[0] == '\0') {
            printf("Input can not be empty!\n");
        } else if (sscanf(line, "%d", &value) != 1) {
            printf("Invalid input. Please enter a number.\n");
        } else if (value < min || value > max) {
            printf("Value must be between %d and %d.\n", min, max);
        } else {
            valid = 1;
        }
    }
    if (out_score) *out_score = value;
    return 1;
}
//calculate average grade
float calculate_average_grade(student s) {
    if (s.subject_count == 0) {
        return 0.0f;
    }
    int total = 0;
    for (int i = 0; i < s.subject_count; i++) {
        total += s.subjects[i].grade;
    }
    return (float)total / (float)s.subject_count;
}

