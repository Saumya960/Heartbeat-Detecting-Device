#include <stdio.h>
#include "report.h"

//line seperator for reports
static const char *LINE = "------------------------------------------------------------";

void print_report(student s){    //print report to console
    printf("%s\n", LINE);
    printf("Student: %s\n", s.name);
    printf("%s\n", LINE);
    printf("%-20s %10s %5s\n", "Subject", "Score", "Grade");
    printf("%s\n", LINE);

    for (int i = 0; i < s.subject_count; i++) {
        printf("%-20.20s %9d%% %5d\n", s.subjects[i].name, s.subjects[i].score, s.subjects[i].grade);
    }

    float average = calculate_average_grade(s);
    printf("\nAverage Grade: %.2f\n", average);
    printf("%s\n", LINE);
}
//write report to a file
void write_report_to_file(student s, const char * filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        printf("Could not open file %s for writing.\n", filename);
        return;
    }
    fprintf(file, "%s\n", LINE);
    fprintf(file, "Student: %s\n", s.name);
    fprintf(file, "%s\n", LINE);
    fprintf(file, "%-20s %10s %5s\n", "Subject", "Score", "Grade");
    fprintf(file, "%s\n", LINE);

    for (int i = 0; i < s.subject_count; i++) {
        fprintf(file, "%-20.20s %9d%% %5d\n", s.subjects[i].name, s.subjects[i].score, s.subjects[i].grade);
    }

    float average = calculate_average_grade(s);
    fprintf(file, "\nAverage Grade: %.2f\n", average);
    fprintf(file, "%s\n", LINE);

    fclose(file);
}
