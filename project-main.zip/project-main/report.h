
#ifndef PROJECT_REPORT_H
#define PROJECT_REPORT_H

#include "grade.h"

void print_report(student s);   //print student's report
void write_report_to_file(student s, const char * filename);   //write student's report to file

#endif //PROJECT_REPORT_H